package com.example.android_app.Utilities

const val DATABASE_NAME = "note_database"